import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-faculty-evaluations',
  templateUrl: './faculty-evaluations.component.html',
  styleUrls: ['./faculty-evaluations.component.scss']
})
export class FacultyEvaluationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
