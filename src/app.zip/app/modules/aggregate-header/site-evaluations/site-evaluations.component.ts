import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-site-evaluations',
  templateUrl: './site-evaluations.component.html',
  styleUrls: ['./site-evaluations.component.scss']
})
export class SiteEvaluationsComponent implements OnInit {
  

  constructor() { }

  ngOnInit() {
  }

}
