import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
@Component({
  selector: 'app-course-evaluations',
  templateUrl: './course-evaluations.component.html',
  styleUrls: ['./course-evaluations.component.scss']
})
export class CourseEvaluationsComponent implements OnInit {
  
  constructor() { 
    
  }

  ngOnInit() {
   
  }

}
