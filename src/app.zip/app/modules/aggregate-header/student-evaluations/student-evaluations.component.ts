import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-student-evaluations',
  templateUrl: './student-evaluations.component.html',
  styleUrls: ['./student-evaluations.component.scss']
})
export class StudentEvaluationsComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }

}
